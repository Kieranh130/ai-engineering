AI ENGINEERING WEBSITE

Contents:
- index.html: responsive one-page website
- assets/ai-engineering-logo.png: the first logo image generated in this conversation

Preview:
Open index.html in a web browser.

Before publishing:
1. Replace the demo phone numbers and email with real business contact details.
2. Check the project description and update it as the design develops.
3. Add real project photos when available.
4. Upload the folder to a web host or connect it to a domain.

This is a static website package. It is built but not published online.
